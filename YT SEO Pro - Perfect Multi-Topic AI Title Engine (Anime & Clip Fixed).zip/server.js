/**
 * India’s YouTube SEO (YT SEO Pro)
 * Hardened Production Node.js & Express Server
 *
 * Implements comprehensive security protections:
 * 1. Security Headers (CSP, HSTS, X-Content-Type-Options, X-Frame-Options, Referrer-Policy, Permissions-Policy)
 * 2. Strict Request Size Limits (Prevents buffer overflow / DoS)
 * 3. In-Memory Sliding-Window Rate Limiting (Mitigates brute-force & API abuse)
 * 4. Secure CORS Control (Restricts cross-origin requests to trusted origins)
 * 5. Sensitive File Access Blocking (Prevents access to .env, .git, config & backup files)
 * 6. Production HTTPS Enforcement (Auto-redirects HTTP to HTTPS)
 * 7. Server Fingerprint Hiding (Disables X-Powered-By)
 * 8. Sanitized Error Handling (Zero leak of server paths, stack traces, or credentials)
 */

const express = require('express');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;
const IS_PROD = process.env.NODE_ENV === 'production';

// 1. Hide Server Fingerprint
app.disable('x-powered-by');

// 2. Production HTTPS Enforcement
app.use((req, res, next) => {
  if (IS_PROD && req.headers['x-forwarded-proto'] && req.headers['x-forwarded-proto'] !== 'https') {
    return res.redirect(301, `https://${req.headers.host}${req.url}`);
  }
  next();
});

// 3. Comprehensive Security Headers
app.use((req, res, next) => {
  // Content Security Policy
  res.setHeader(
    'Content-Security-Policy',
    "default-src 'self'; script-src 'self' 'unsafe-inline' https://fonts.googleapis.com; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data: https:; connect-src 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'self'; form-action 'self';"
  );
  // Prevent MIME-sniffing
  res.setHeader('X-Content-Type-Options', 'nosniff');
  // Prevent Clickjacking
  res.setHeader('X-Frame-Options', 'DENY');
  // Referrer Policy
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  // Permissions Policy
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=(), payment=()');
  // HSTS (HTTP Strict Transport Security) in production
  if (IS_PROD) {
    res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains; preload');
  }
  next();
});

// 4. Secure CORS Configuration
const allowedOrigins = process.env.ALLOWED_ORIGINS
  ? process.env.ALLOWED_ORIGINS.split(',').map(o => o.trim())
  : ['http://localhost:3000', 'https://indiayoutubeseo.com'];

app.use((req, res, next) => {
  const origin = req.headers.origin;
  if (origin && allowedOrigins.includes(origin)) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  }
  if (req.method === 'OPTIONS') {
    return res.sendStatus(204);
  }
  next();
});

// 5. In-Memory Sliding-Window Rate Limiting (Zero external dependencies)
const rateLimitMap = new Map();
function rateLimiter(options) {
  const windowMs = options.windowMs || 60000;
  const max = options.max || 30;

  return (req, res, next) => {
    const ip = req.ip || req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown';
    const now = Date.now();

    if (!rateLimitMap.has(ip)) {
      rateLimitMap.set(ip, []);
    }

    const timestamps = rateLimitMap.get(ip).filter(t => now - t < windowMs);
    timestamps.push(now);
    rateLimitMap.set(ip, timestamps);

    if (timestamps.length > max) {
      res.setHeader('Retry-After', Math.ceil(windowMs / 1000));
      return res.status(429).json({
        error: 'Too many requests. Please try again later.'
      });
    }
    next();
  };
}

// Clean up stale rate-limit memory every 5 minutes
setInterval(() => {
  const now = Date.now();
  for (const [ip, timestamps] of rateLimitMap.entries()) {
    const valid = timestamps.filter(t => now - t < 300000);
    if (valid.length === 0) {
      rateLimitMap.delete(ip);
    } else {
      rateLimitMap.set(ip, valid);
    }
  }
}, 300000);

// Global Limiter (120 req / minute) & API Limiter (20 req / minute)
app.use(rateLimiter({ windowMs: 60000, max: 120 }));
const apiLimiter = rateLimiter({ windowMs: 60000, max: 20 });

// 6. Strict Request Size Limits
app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: true, limit: '10kb' }));

// 7. Sensitive Files & Dotfile Blocking
app.use((req, res, next) => {
  const blockedPatterns = [
    /\/\./,                   // Any dotfile (.env, .git, .gitignore, etc.)
    /package(-lock)?\.json$/, // Package manifests
    /server\.js$/,            // Server source
    /\.bak$/i,                // Backup files
    /\.config$/i,             // Config files
    /\.sql$/i,                // Database dumps
    /\.zip$/i                 // Archive files
  ];

  for (const pattern of blockedPatterns) {
    if (pattern.test(req.path)) {
      return res.status(403).json({ error: 'Access denied.' });
    }
  }
  next();
});

// 8. Static Assets Serving with Safe Caching
app.use(express.static(path.join(__dirname), {
  dotfiles: 'deny',
  maxAge: '1d',
  setHeaders: (res, filePath) => {
    if (filePath.endsWith('.html')) {
      res.setHeader('Cache-Control', 'no-cache');
    }
  }
}));

// 9. Protected Backend API Route (Ready for secure external LLM calls)
app.post('/api/generate-seo', apiLimiter, async (req, res) => {
  try {
    const { topic } = req.body;

    if (!topic || typeof topic !== 'string' || topic.trim().length === 0) {
      return res.status(400).json({ error: 'Please enter a valid YouTube title or video topic.' });
    }

    // Sanitize & enforce max input length to prevent ReDoS / payload abuse
    const cleanTopic = topic.trim().slice(0, 200);

    // If an external LLM API Key is configured in environment variables
    if (process.env.AI_API_KEY) {
      // Secret API key is held exclusively on the server side
      // NEVER pass or return process.env.AI_API_KEY to the client
      // const response = await fetch('https://api.provider.com/v1/generate', { ... });
    }

    return res.json({
      status: 'success',
      sanitizedTopic: cleanTopic,
      message: 'Processed securely via server-side engine.'
    });

  } catch (error) {
    // Sanitize error response: NEVER leak stack trace, internal paths, or API keys
    return res.status(500).json({ error: 'Something went wrong. Please try again.' });
  }
});

// 10. 404 Catch-All Handler
app.use((req, res) => {
  res.status(404).sendFile(path.join(__dirname, 'index.html'));
});

// 11. Centralized Safe Error Handler
app.use((err, req, res, next) => {
  // Check for payload too large
  if (err && (err.type === 'entity.too.large' || err.status === 413)) {
    return res.status(413).json({ error: 'Payload too large. Maximum allowed size is 10KB.' });
  }
  // Generic error response: no internal stack traces leaked
  res.status(500).json({ error: 'An unexpected error occurred. Please try again.' });
});

// Start Server
app.listen(PORT, () => {
  console.log(`India’s YouTube SEO (YT SEO Pro) running securely on port ${PORT}`);
});