/**
 * India’s YouTube SEO (YT SEO Pro)
 * Core Engine & Interactive UI Manager
 * Fully tested, resilient, and production-ready
 */

(function() {
  'use strict';

  // State
  const state = {
    currentInput: '',
    results: null,
    isLoading: false,
    activeView: 'home'
  };

  // Helper to safely get element
  function $(id) {
    return document.getElementById(id);
  }

  // --- Router for Multi-page Experience ---
  function initRouter() {
    function handleRoute() {
      const hash = window.location.hash.replace('#', '') || 'home';
      showView(hash);
    }

    window.addEventListener('hashchange', handleRoute);
    handleRoute();

    // Nav link click events
    document.querySelectorAll('.nav-link').forEach(link => {
      link.addEventListener('click', (e) => {
        const targetView = link.getAttribute('data-view');
        if (targetView) {
          e.preventDefault();
          window.location.hash = targetView;
          const navMenu = $('navMenu');
          if (navMenu) navMenu.classList.remove('mobile-open');
        }
      });
    });

    // Mobile hamburger menu toggle
    const mobileToggle = $('mobileToggle');
    const navMenu = $('navMenu');
    if (mobileToggle && navMenu) {
      mobileToggle.addEventListener('click', () => {
        navMenu.classList.toggle('mobile-open');
      });
    }
  }

  function showView(viewId) {
    const views = document.querySelectorAll('.page-view');
    let matched = false;

    views.forEach(v => {
      if (v.id === `view-${viewId}`) {
        v.classList.add('active');
        matched = true;
      } else {
        v.classList.remove('active');
      }
    });

    if (!matched && $('view-home')) {
      $('view-home').classList.add('active');
      viewId = 'home';
    }

    state.activeView = viewId;

    // Update active state in navigation
    document.querySelectorAll('.nav-link').forEach(link => {
      if (link.getAttribute('data-view') === viewId) {
        link.classList.add('active');
      } else {
        link.classList.remove('active');
      }
    });

    // Scroll to top on page navigation (unless staying on home)
    if (viewId !== 'home' || !window.location.hash.includes('tool')) {
      if (typeof window.scrollTo === 'function') window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }

  // --- Topic Analysis & Generation Engine ---
  function cleanInput(text) {
    if (!text) return '';
    return String(text).slice(0, 200).replace(/[<>{}[\]]/g, '').trim();
  }

  function cleanSubject(raw, category) {
    if (!raw) return '';
    let s = raw.trim().replace(/[!?.]+$/, '').trim();

    // Strip generic query prefixes
    const prefixes = [
        /^(how to\s+|how do i\s+|how can i\s+|how i\s+)/i,
        /^(best\s+way\s+to\s+|best\s+ways\s+to\s+)/i,
        /^(top\s+\d+\s+|best\s+\d+\s+|\d+\s+best\s+|\d+\s+top\s+)/i,
        /^(the\s+best\s+|the\s+ultimate\s+|complete\s+guide\s+to\s+)/i,
        /^(tips\s+for\s+|tricks\s+for\s+|guide\s+to\s+|guide\s+for\s+)/i
    ];
    for (const p of prefixes) {
        s = s.replace(p, '').trim();
    }

    // Category-specific redundant word stripping
    if (category === 'cooking') {
        s = s.replace(/\b(restaurant style|dhaba style|recipe|recipes|ki recipe|kaise banaye|banane ka tarika|special recipe)\b/gi, '').trim();
        s = s.replace(/[\s&,-]+$/, '').trim();
    } else if (category === 'tech') {
        s = s.replace(/\b(full review|honest review|review|reviews|unboxing|camera test|speed test|battery test)\b/gi, '').trim();
        s = s.replace(/[\s&,-]+$/, '').trim();
    } else if (category === 'music') {
        s = s.replace(/\b(full song|audio|mp3|video song)\b/gi, '').trim();
        s = s.replace(/[\s&,-]+$/, '').trim();
    } else if (category === 'gaming') {
        s = s.replace(/\b(gameplay|walkthrough|playthrough|gaming)\b/gi, '').trim();
        s = s.replace(/[\s&,-]+$/, '').trim();
    } else if (category === 'fitness') {
        s = s.replace(/\b(workout|workouts|exercises|exercise|routine|training)\b/gi, '').trim();
        s = s.replace(/[\s&,-]+$/, '').trim();
    } else if (category === 'vlog') {
        s = s.replace(/^(my\s+)?(daily\s+)?(routine\s+)?(vlog\s+)?(in\s+)?/gi, '').trim();
        s = s.replace(/\b(vlog|daily vlog|travel vlog)\b/gi, '').trim();
        s = s.replace(/[\s&,-]+$/, '').trim();
    } else if (category === 'education') {
        s = s.replace(/\b(full tutorial|tutorial|tutorials|full course|course)\b/gi, '').trim();
        s = s.replace(/[\s&,-]+$/, '').trim();
    }

    // Convert leading action verbs to gerunds for natural phrasing
    s = s.replace(/^Invest\b/i, 'Investing')
         .replace(/^Grow\b/i, 'Growing')
         .replace(/^Get\b/i, 'Getting')
         .replace(/^Earn\b/i, 'Earning')
         .replace(/^Make\b/i, 'Making')
         .replace(/^Start\b/i, 'Starting')
         .replace(/^Build\b/i, 'Building')
         .replace(/^Learn\b/i, 'Learning')
         .replace(/^Edit\b/i, 'Editing');

    const words = s.split(/\s+/).filter(Boolean);
    const capitalized = words.map(w => {
      if (w.toUpperCase() === w && w.length <= 4) return w; // keep acronyms like GTA, BGMI, COD, PC, SEO
      return w.charAt(0).toUpperCase() + w.slice(1).toLowerCase();
    }).join(' ');

    return capitalized || raw.trim().split(/\s+/).map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join(' ');
  }

  function toGerund(phrase) {
    if (!phrase) return '';
    return phrase
      .replace(/^Grow\b/i, 'Growing')
      .replace(/^Start\b/i, 'Starting')
      .replace(/^Make\b/i, 'Making')
      .replace(/^Build\b/i, 'Building')
      .replace(/^Edit\b/i, 'Editing')
      .replace(/^Learn\b/i, 'Learning')
      .replace(/^Get\b/i, 'Getting')
      .replace(/^Find\b/i, 'Finding')
      .replace(/^Create\b/i, 'Creating')
      .replace(/^Earn\b/i, 'Earning')
      .replace(/^Increase\b/i, 'Increasing');
  }

  function analyzeTopic(rawInput) {
    const input = cleanInput(rawInput);
    const charCount = input.length;
    const lower = input.toLowerCase();

    // 1. Detect Niche / Category (Including Anime, Movie Scenes, Fight Clips, Sports, Entertainment)
    let category = "general";
    let intent = "Video Topic / YouTube Content";

    // Check for Anime / Movie / Fight Scene / Entertainment Clips / Action Moments first
    const isSceneOrClip = /\b(naruto|sasuke|boruto|rasengan|luffy|zoro|one piece|goku|vegeta|dragon ball|gojo|sukuna|jujutsu kaisen|demon slayer|tanjiro|anime|manga|marvel|avengers|thanos|iron man|batman|superman|spiderman|movie scene|film|fight scene|full fight|battle|defeated|destroys|kills|slaps|attacks|transformation|awakening|epic scene|epic moment|climax|ending scene|clip|scene|episode|tastes|fights|beats|vs|versus|reaction to|reacting to)\b/i.test(lower);
    const isSports = /\b(cricket|football|messi|ronaldo|kohli|rohit|dhoni|ipl|fifa|goal|six|wicket|match|highlights|real madrid|barcelona|champion)\b/i.test(lower);

    if (isSceneOrClip) {
      category = "scene";
      intent = "Anime / Movie Scene & Epic Clip";
    } else if (isSports) {
      category = "sports";
      intent = "Sports / Match Highlights & Moments";
    } else if (/\b(song|songs|music|lofi|mashup|remix|acoustic|cover|lyrics|album|beat|track|singer|arijit|bollywood|audio|listen|romantic|sad|melody|qawwali|ghazal)\b/i.test(lower)) {
      category = "music";
      intent = "Entertainment / Music & Audio";
    } else if (/\b(game|gaming|gameplay|minecraft|bgmi|pubg|free fire|gta|roblox|fortnite|valorant|cod|warzone|esports|walkthrough|playthrough|fps|clutch|boss|speedrun|streamer)\b/i.test(lower)) {
      category = "gaming";
      intent = "Gaming / Entertainment & Walkthrough";
    } else if (/\b(review|unboxing|camera test|battery|specs|benchmark|tested|worth it|iphone|samsung|android|laptop|gpu|gadget|processor|smartphone|macbook|ipad)\b/i.test(lower)) {
      category = "tech";
      intent = "Product Review / Tech Analysis";
    } else if (/\b(recipe|cooking|kitchen|cook|dish|street food|masala|paneer|chicken|biryani|breakfast|lunch|dinner|curry|halwai|chai|delicious|baking|cake|snack)\b/i.test(lower)) {
      category = "cooking";
      intent = "Cooking / Food & Recipe Guide";
    } else if (/\b(vlog|travel|trip|routine|day in my life|morning routine|night routine|tour|village|mumbai|delhi|explore|exploring|vacation|living in|room tour)\b/i.test(lower)) {
      category = "vlog";
      intent = "Lifestyle / Travel & Personal Vlog";
    } else if (/\b(money|earn|earning|finance|invest|investing|stock|stocks|mutual fund|sip|crypto|trading|passive income|business|salary|side hustle|wealth|rich)\b/i.test(lower)) {
      category = "finance";
      intent = "Finance / Investment & Business";
    } else if (/\b(workout|gym|fitness|fat loss|weight loss|muscle|biceps|chest|diet|exercise|abs|calisthenics|training|bodybuilding|belly fat)\b/i.test(lower)) {
      category = "fitness";
      intent = "Health / Fitness & Workout Routine";
    } else if (/\b(channel|views|subscribers|algorithm|youtube growth|youtube seo|shorts algorithm|monetize|retention|impressions|ctr|grow youtube|capcut|premiere|video editing|edit video|editing)\b/i.test(lower)) {
      category = "creator";
      intent = /edit|capcut|premiere/i.test(lower) ? "Video Editing / Creator Skills" : "Creator Advice / Channel Growth";
    } else if (/\b(tutorial|how to|learn|code|coding|python|javascript|react|blender|guide|course|lecture|exam|class 10|class 12)\b/i.test(lower)) {
      category = "education";
      intent = "Educational / Skill Tutorial";
    } else if (/\b(funny|comedy|prank|roast|reaction|challenge|comedy video|meme|storytime)\b/i.test(lower)) {
      category = "entertainment";
      intent = "Entertainment / Comedy & Humor";
    }

    // Split words & extract core tokens
    const words = input.split(/\s+/).filter(w => w.length > 0);
    const stopWords = new Set(['a', 'an', 'the', 'in', 'on', 'at', 'to', 'for', 'of', 'and', 'or', 'is', 'are', 'my', 'your', 'video', 'youtube', 'how', 'best', 'top', 'new', '2026', '2025']);
    const coreTokens = words
      .map(w => w.toLowerCase().replace(/[^a-zA-Z0-9]/gi, ''))
      .filter(w => w.length > 2 && !stopWords.has(w));

    const primaryTerm = coreTokens.length > 0 ? coreTokens[0] : (words[0] || 'video');
    const mainKeyword = coreTokens.length > 0 ? coreTokens.slice(0, 3).join(' ') : input;

    // Cleaned Subject and Title Variants
    const cleanSubj = cleanSubject(input, category);
    const gerundSubj = toGerund(cleanSubj);
    const origTitle = input.replace(/[!?.]+$/, '').trim().split(/\s+/).map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join(' ');

    // Realistic SEO Scoring
    let score = 72;
    const strengths = [];
    const weaknesses = [];
    const improvements = [];
    let lengthQuality = "Good (35-70 chars)";

    if (charCount >= 40 && charCount <= 65) {
      score += 12;
      lengthQuality = "Optimal (40-65 chars)";
      strengths.push("Title length is well-balanced for mobile & desktop displays (40–65 characters).");
    } else if (charCount < 25) {
      score -= 6;
      lengthQuality = "Short (< 25 chars)";
      weaknesses.push("Topic or title is brief; consider adding a target audience or benefit qualifier.");
      improvements.push("Incorporate long-tail keywords (e.g., target audience, year, or format).");
    } else if (charCount > 75) {
      score -= 5;
      lengthQuality = "Long (> 75 chars)";
      weaknesses.push("Title exceeds 70 characters and may get cut off on mobile search feeds.");
      improvements.push("Front-load your most important keyword within the first 45 characters.");
    } else {
      score += 4;
      strengths.push("Good descriptive length that clearly conveys the subject.");
    }

    if (coreTokens.length >= 2) {
      score += 8;
      strengths.push(`Clear topical focus identified around "${mainKeyword}".`);
    } else {
      weaknesses.push("Narrow keyword context; search crawlers prefer more descriptive phrasing.");
      improvements.push("Add a specific angle or target group to widen search discoverability.");
    }

    // Power words detection
    if (/beginner|complete|step by step|guide|proven|easy|fast|secret|mastery|formula|ultimate|framework|avoid|best|review|recipe|full|official/i.test(lower)) {
      score += 6;
      strengths.push("Contains engaging intent markers that assist search click-through.");
    } else {
      improvements.push("Consider pairing with an engaging qualifier (e.g., 'Step-by-Step', 'Review', 'Honest Verdict').");
    }

    score = Math.min(Math.max(score, 62), 94);

    let statusText = "Good foundation — modest refinement suggested.";
    if (score >= 84) {
      statusText = "Your title is already well optimized.";
    } else if (score < 70) {
      statusText = "Needs structural improvement to maximize search visibility.";
    }

    // Category-Specific Improved Titles (Engineered Exactly Like ChatGPT for Real YouTubers)
    let improvedTitles = [];

    if (category === "scene") {
      const actionMatch = input.match(/(.+?)\s+(?:vs\.?|versus|fights|beats|destroys|tastes|meets|slaps|saves|kills|attacks|enters)\s+(.+)/i);
      if (actionMatch) {
        const charA = cleanSubject(actionMatch[1], category);
        const charB = cleanSubject(actionMatch[2], category);
        improvedTitles = [
          {
            title: `When ${charA} Thought They Could Take On ${charB}... 😱`,
            reason: "High-Hype Curiosity Hook: Focuses on the dramatic turning point that anime and clip fans click instantly.",
            recommended: true
          },
          {
            title: `${origTitle} | Full Fight Scene 4K 60FPS [HD]`,
            reason: "Search & Quality Magnet: Captures high-intent searches from viewers wanting the clean, high-resolution scene.",
            recommended: false
          },
          {
            title: `The Exact Moment ${charA} Realized Their Huge Mistake! (Chills)`,
            reason: "Emotional Hype Hook: Highlights the character power demonstration that triggers comments and shares.",
            recommended: false
          },
          {
            title: `${charA} vs ${charB} (Epic Climax Battle Clip)`,
            reason: "Direct Descriptive Hook: Clean, professional title that YouTube easily serves in up-next suggested feeds.",
            recommended: false
          },
          {
            title: `Nobody Expected This to Happen to ${charA}! (Unbelievable Moment)`,
            reason: "Viral Browse Hook: Proven curiosity angle that generates massive clicks on mobile home feeds.",
            recommended: false
          }
        ];
      } else {
        improvedTitles = [
          {
            title: `When Everyone Thought It Was Over... But Then THIS Happened! 😱`,
            reason: "High-Hype Curiosity Hook: Focuses on the dramatic turning point that anime and clip fans click instantly.",
            recommended: true
          },
          {
            title: `${origTitle} | Full Scene 4K 60FPS [HD]`,
            reason: "Search & Quality Magnet: Captures high-intent searches from viewers wanting the clean, high-resolution scene.",
            recommended: false
          },
          {
            title: `The Exact Moment Everyone Got Chills! (${cleanSubj} Epic Scene)`,
            reason: "Emotional Hype Hook: Highlights the character power demonstration that triggers comments and shares.",
            recommended: false
          },
          {
            title: `${origTitle} (Epic Climax Battle Clip)`,
            reason: "Direct Descriptive Hook: Clean, professional title that YouTube easily serves in up-next suggested feeds.",
            recommended: false
          },
          {
            title: `Nobody Expected This Scene to Go So Hard! (${cleanSubj})`,
            reason: "Viral Browse Hook: Proven curiosity angle that generates massive clicks on mobile home feeds.",
            recommended: false
          }
        ];
      }
    } else if (category === "sports") {
      improvedTitles = [
        {
          title: `When ${cleanSubj} Shocked the Entire World! (Unbelievable Moments)`,
          reason: "High-Emotion Climax: Captures peak sports excitement that fans love to re-watch.",
          recommended: true
        },
        {
          title: `${origTitle} | Full Match Highlights [HD 60FPS]`,
          reason: "Clean Search Magnet: Direct search title for viewers looking for replay clips.",
          recommended: false
        },
        {
          title: `The Exact Moment ${cleanSubj} Changed the Entire Game! (Chills)`,
          reason: "Key Moment Hook: Centers on the decisive turning point of the match.",
          recommended: false
        },
        {
          title: `Nobody Expected ${cleanSubj} to Pull Off THIS Miracle!`,
          reason: "Dramatic Narrative Hook: High click-through rate angle for sports fans.",
          recommended: false
        },
        {
          title: `Top Legendary Moments of ${cleanSubj} (Emotional Finish)`,
          reason: "Compilation / Nostalgia Hook: Drives long watch-time from loyal sports fans.",
          recommended: false
        }
      ];
    } else if (category === "music") {
      improvedTitles = [
        {
          title: `${cleanSubj} That Hit Right in the Feels | 1 Hour Chillout Lofi Mix 🌧️`,
          reason: "High Emotional Resonance: Captures late-night mood searches and drives continuous playlist looping.",
          recommended: true
        },
        {
          title: `Best of ${cleanSubj} (Slowed + Reverb with Full Lyrics) | Late Night Vibes`,
          reason: "Trending Audio Format: Captures massive search demand for slowed aesthetic audio with lyrics.",
          recommended: false
        },
        {
          title: `Songs That Make You Feel Like You're in a Movie (${cleanSubj} Special)`,
          reason: "Curiosity & Cinematic Hook: High click-through rate angle proven on the YouTube homepage.",
          recommended: false
        },
        {
          title: `Heart Touching ${cleanSubj} | Non-Stop Acoustic & Unplugged Jukebox`,
          reason: "Authentic Unplugged Format: Ideal for background study, work, and long driving sessions.",
          recommended: false
        },
        {
          title: `When Words Fail, Music Speaks: Top ${cleanSubj} Hits (2026 Melodies)`,
          reason: "Poetic Title Case: Combines emotional connection with current calendar year freshness.",
          recommended: false
        }
      ];
    } else if (category === "creator") {
      const isSubs = /subscribers|subs/i.test(input);
      const isViews = /views|watch time/i.test(input);
      const isEdit = /editing|edit|capcut|premiere/i.test(input);

      if (isSubs) {
        improvedTitles = [
          {
            title: `How to Get Your First 1,000 Subscribers Fast (What ACTUALLY Worked for Me)`,
            reason: "Personal Experience Hook: Case-study title that outperforms generic theory in YouTube search.",
            recommended: true
          },
          {
            title: `I Tried Growing a New YouTube Channel for 30 Days (Here’s The Truth)`,
            reason: "Story & Challenge Hook: Generates massive curiosity and high initial audience retention.",
            recommended: false
          },
          {
            title: `Get 1,000 Subscribers in 2026 | 5 Steps for Small Creators (No Paid Promo)`,
            reason: "Two-Part Split Title: Clean balance of search keywords and realistic advice for beginners.",
            recommended: false
          },
          {
            title: `Stop Doing This if You Want Subscribers (The #1 Mistake Killing Your Channel)`,
            reason: "Urgent Loss-Aversion Hook: Directly addresses creator frustration and drives clicks.",
            recommended: false
          },
          {
            title: `The Only YouTube Growth Strategy You Need as a Beginner (0 to 1K Blueprint)`,
            reason: "Definitive Blueprint: Reassuring, noise-free roadmap that creators save and re-watch.",
            recommended: false
          }
        ];
      } else if (isEdit) {
        const softwareName = cleanSubj.replace(/^(video editing in|editing in|editing videos in|how to edit in)\s+/i, '').trim() || 'Video Editor';
        improvedTitles = [
          {
            title: `Edit Like a Pro in ${softwareName} in 10 Minutes (Full Beginner Tutorial)`,
            reason: "Fast Payoff Promise: Combines low time commitment with professional-quality editing tips.",
            recommended: true
          },
          {
            title: `5 ${softwareName} Editing Tricks That Feel Like Magic (Most Creators Don't Know)`,
            reason: "Secret Tricks Hook: High-curiosity angle that appeals to both beginners and existing editors.",
            recommended: false
          },
          {
            title: `How to Edit Viral Reels & Shorts in ${softwareName} (Step-by-Step 2026)`,
            reason: "Short-Form Demand: Directly targets creators looking to make viral vertical videos.",
            recommended: false
          },
          {
            title: `Stop Making These 3 Editing Mistakes in ${softwareName}! (Fix Your Quality)`,
            reason: "Diagnostic Problem-Solver: Corrects visual mistakes that make amateur videos look sloppy.",
            recommended: false
          },
          {
            title: `${softwareName} Editing Secrets | Simple Cuts for Maximum Audience Retention`,
            reason: "Two-Part Split Title: Connects editing workflow directly with YouTube's watch-time algorithm.",
            recommended: false
          }
        ];
      } else {
        const cleanGoal = cleanSubj.replace(/^Growing\b/i, 'Grow').replace(/^Getting\b/i, 'Get');
        improvedTitles = [
          {
            title: `How to ${cleanGoal} in 2026 (The Strategy That ACTUALLY Works)`,
            reason: "High-Confidence Search: Cuts through saturated, outdated advice with a fresh 2026 angle.",
            recommended: true
          },
          {
            title: `Why Small Channels Struggle to ${cleanGoal} (And How to Fix It Today)`,
            reason: "Direct Pain-Point Hook: Solves common creator struggles without unrealistic hype.",
            recommended: false
          },
          {
            title: `I Tested the YouTube Algorithm for 30 Days (Here’s What I Learned About ${cleanGoal})`,
            reason: "Story & Experiment Hook: Real case studies generate significantly higher CTR than generic theory.",
            recommended: false
          },
          {
            title: `${cleanGoal} Blueprint | 5 Simple Steps for Small YouTube Creators`,
            reason: "Two-Part Split Title: Clear, punchy structure tailored for mobile YouTube feeds.",
            recommended: false
          },
          {
            title: `The Realistic Roadmap to ${cleanGoal} (Without Burning Out)`,
            reason: "Empathetic Masterclass: Practical creator advice balancing growth with sustainability.",
            recommended: false
          }
        ];
      }
    } else if (category === "gaming") {
      improvedTitles = [
        {
          title: `How to Play Like a Pro in ${cleanSubj} (5 Settings You MUST Change)`,
          reason: "Actionable Skill Hook: Immediate value promise that competitive gamers click instantly.",
          recommended: true
        },
        {
          title: `I Survived 100 Days in ${cleanSubj}... Here's What Happened (Hardcore)`,
          reason: "Storytelling Format: High-stakes narrative progression with exceptional audience watch-time.",
          recommended: false
        },
        {
          title: `The Most Insane Clutch in ${cleanSubj} History! (Rank Push Gameplay)`,
          reason: "Two-Part Split Title: High-energy highlight title optimized for high click-through in browse feeds.",
          recommended: false
        },
        {
          title: `Stop Making These 5 Fatal Mistakes in ${cleanSubj} (You're Dying for Nothing)`,
          reason: "Loss-Aversion Diagnostic Hook: Blunt, relatable advice that competitive gamers immediately click.",
          recommended: false
        },
        {
          title: `${cleanSubj} from Zero to Pro: The Complete 2026 Beginner's Walkthrough`,
          reason: "Beginner-to-Pro Blueprint: Clean walkthrough format for new players entering the game.",
          recommended: false
        }
      ];
    } else if (category === "cooking") {
      improvedTitles = [
        {
          title: `Restaurant Style ${cleanSubj} at Home (The Secret Nobody Tells You!)`,
          reason: "Taste & Secret Promise: Promises 5-star hotel flavor with ordinary home kitchen tools.",
          recommended: true
        },
        {
          title: `How to Make Perfect ${cleanSubj} in 15 Minutes (Super Easy for Beginners)`,
          reason: "Speed & Simplicity Hook: Eliminates cooking hesitation by emphasizing fast prep time.",
          recommended: false
        },
        {
          title: `The Only ${cleanSubj} Recipe You'll Ever Need (Secret Spices Revealed)`,
          reason: "Definitive Recipe Title: Establishes instant culinary authority and confidence.",
          recommended: false
        },
        {
          title: `Secret to Soft & Juicy ${cleanSubj} (Dhaba Style Step-by-Step)`,
          reason: "Texture & Flavour Solution: Solves the biggest common cooking pitfalls with ease.",
          recommended: false
        },
        {
          title: `Make Delicious ${cleanSubj} with Basic Spices | Easy Everyday Recipe`,
          reason: "Pantry-Friendly Angle: Lowers the barrier to entry by highlighting everyday kitchen ingredients.",
          recommended: false
        }
      ];
    } else if (category === "tech") {
      improvedTitles = [
        {
          title: `${cleanSubj}: The Honest Truth After 30 Days (Don't Buy Yet!)`,
          reason: "Buyer Decision Search: High-intent pre-purchase shoppers seeking unbiased long-term testing.",
          recommended: true
        },
        {
          title: `Don't Waste Your Money! ${cleanSubj} Review (Honest Pros & Cons)`,
          reason: "Urgent FOMO Hook: Generates massive click-through from browse features by answering buying doubts.",
          recommended: false
        },
        {
          title: `5 Things I Wish I Knew Before Buying the ${cleanSubj}`,
          reason: "Buyer Regret Prevention: Highly relatable format that potential owners watch before purchasing.",
          recommended: false
        },
        {
          title: `${cleanSubj} Real-World Test | Battery, Camera & Speed Verdict (2026)`,
          reason: "Two-Part Split Title: Covers the exact three specifications viewers care about most.",
          recommended: false
        },
        {
          title: `Is the ${cleanSubj} Actually Worth the Upgrade? (The Real Verdict)`,
          reason: "Direct Answer Format: Fast-paced decision-making title for cost-conscious consumers.",
          recommended: false
        }
      ];
    } else if (category === "vlog") {
      improvedTitles = [
        {
          title: `Exploring ${cleanSubj}: What Nobody Tells You (Travel Vlog 2026)`,
          reason: "Authenticity & Discovery: Promises genuine behind-the-scenes reality rather than staged scenes.",
          recommended: true
        },
        {
          title: `My Real Daily Routine in ${cleanSubj} (A Day in My Life)`,
          reason: "Personal Connection Hook: Fosters deep subscriber loyalty and sustained organic watch-time.",
          recommended: false
        },
        {
          title: `We Spent 24 Hours in ${cleanSubj} on a Budget! (Full Experience)`,
          reason: "Challenge & Budget Hook: Constraint-based narrative stakes create immediate viewer curiosity.",
          recommended: false
        },
        {
          title: `The Hidden Side of ${cleanSubj}: What Locals Never Show Tourists`,
          reason: "Offbeat Discovery Angle: Appeals strongly to travelers searching for unique, non-commercial spots.",
          recommended: false
        },
        {
          title: `Traveling to ${cleanSubj} | Complete Budget, Safety & Itinerary Guide`,
          reason: "Two-Part Split Title: High-utility title capturing trip-planning searchers looking for practical advice.",
          recommended: false
        }
      ];
    } else if (category === "finance") {
      improvedTitles = [
        {
          title: `How to Start ${cleanSubj} in 2026: Complete Beginner's Blueprint`,
          reason: "Foundational Blueprint: Direct, trustworthy entry point into financial planning.",
          recommended: true
        },
        {
          title: `The Smart Way to Approach ${cleanSubj} (Avoid These 5 Costly Mistakes)`,
          reason: "Loss-Aversion Psychology: Protects viewers from losing money and establishes immediate authority.",
          recommended: false
        },
        {
          title: `${cleanSubj} Blueprint | How I Built a Realistic Income Stream`,
          reason: "Two-Part Split Title: Transparent case-study positioning proving authenticity without get-rich hype.",
          recommended: false
        },
        {
          title: `Is ${cleanSubj} Still Worth It in 2026? Realistic Numbers Revealed`,
          reason: "Market Reality Check: Directly resolves economic doubts for prospective investors.",
          recommended: false
        },
        {
          title: `5 ${cleanSubj} Rules I Wish I Followed Sooner (Beginner Friendly)`,
          reason: "Relatable Wisdom Format: High subscriber conversion format appealing strongly to young professionals.",
          recommended: false
        }
      ];
    } else if (category === "fitness") {
      improvedTitles = [
        {
          title: `The Most Effective ${cleanSubj} Routine for Real Results (Science-Backed)`,
          reason: "Outcome & Routine Focus: Direct outcome-focused title backed by structured exercise clarity.",
          recommended: true
        },
        {
          title: `Stop Doing ${cleanSubj} Like This! (Fix Your Form & Avoid Injury)`,
          reason: "Corrective Warning Hook: Protects viewers and establishes trainer credibility while driving viral clicks.",
          recommended: false
        },
        {
          title: `${cleanSubj} Workout Plan | Build Muscle & Burn Fat at Home`,
          reason: "Two-Part Split Title: Covers the dual benefits viewers search for in home workout routines.",
          recommended: false
        },
        {
          title: `How to See Real Progress with ${cleanSubj} in 30 Days (Do This Daily)`,
          reason: "Time-Bound Milestone: Sets clear, motivating, and achievable viewer expectations.",
          recommended: false
        },
        {
          title: `5 Common ${cleanSubj} Mistakes Killing Your Gains (Fix Them Today)`,
          reason: "Diagnostic Problem-Solver: Pinpoints hidden gym errors that frustrate dedicated lifters.",
          recommended: false
        }
      ];
    } else {
      // General Versatile Fallback (Never assumes it's a tutorial or 30-day study!)
      improvedTitles = [
        {
          title: `${origTitle} | The Full Story & Breakdown (2026)`,
          reason: "Search & Context Magnet: Clear, professional title case that ranks high in YouTube search.",
          recommended: true
        },
        {
          title: `The Truth About ${origTitle} That Nobody Talks About!`,
          reason: "Curiosity & Intrigue Hook: Proven storytelling hook that pulls clicks from suggested video feeds.",
          recommended: false
        },
        {
          title: `${origTitle} Explained | Everything You Need to Know`,
          reason: "Two-Part Split Title: Balanced structure providing instant clarity to mobile viewers.",
          recommended: false
        },
        {
          title: `What REALLY Happened During ${origTitle}? (Shocking Facts)`,
          reason: "Revelation Hook: Piques high viewer curiosity without deceptive clickbait.",
          recommended: false
        },
        {
          title: `Why Everyone Is Talking About ${origTitle} Right Now!`,
          reason: "Social Proof Hook: High-engagement framing that drives organic click-through.",
          recommended: false
        }
      ];
    }

    // Category-Specific Tags
    const tagsSet = new Set();
    tagsSet.add(lower);
    if (cleanSubj && cleanSubj.toLowerCase() !== lower) tagsSet.add(cleanSubj.toLowerCase());

    if (category === "music") {
      tagsSet.add(`${lower} song`);
      tagsSet.add(`${cleanSubj.toLowerCase()} lofi`);
      tagsSet.add(`${cleanSubj.toLowerCase()} lyrics`);
      tagsSet.add(`best of ${cleanSubj.toLowerCase()}`);
      tagsSet.add(`${cleanSubj.toLowerCase()} romantic songs`);
      tagsSet.add(`${cleanSubj.toLowerCase()} slowed reverb`);
      tagsSet.add(`${cleanSubj.toLowerCase()} mashup`);
      tagsSet.add(`${cleanSubj.toLowerCase()} audio`);
      tagsSet.add("heart touching songs");
      tagsSet.add("chillout music mix");
      tagsSet.add("romantic hindi songs");
      tagsSet.add("late night lofi vibes");
      tagsSet.add("sad song hindi");
      tagsSet.add(`${cleanSubj.toLowerCase()} 2026`);
    } else if (category === "gaming") {
      tagsSet.add(`${lower} gameplay`);
      tagsSet.add(`${cleanSubj.toLowerCase()} walkthrough`);
      tagsSet.add(`${cleanSubj.toLowerCase()} pro tips`);
      tagsSet.add(`${cleanSubj.toLowerCase()} hardcore`);
      tagsSet.add(`${cleanSubj.toLowerCase()} clutch`);
      tagsSet.add(`how to play ${cleanSubj.toLowerCase()}`);
      tagsSet.add(`${cleanSubj.toLowerCase()} highlights`);
      tagsSet.add(`${cleanSubj.toLowerCase()} guide`);
      tagsSet.add(`${cleanSubj.toLowerCase()} secrets`);
      tagsSet.add("best gaming moments");
      tagsSet.add(`${cleanSubj.toLowerCase()} 2026`);
    } else if (category === "tech") {
      tagsSet.add(`${lower} review`);
      tagsSet.add(`${cleanSubj.toLowerCase()} unboxing`);
      tagsSet.add(`${cleanSubj.toLowerCase()} camera test`);
      tagsSet.add(`${cleanSubj.toLowerCase()} battery test`);
      tagsSet.add(`${cleanSubj.toLowerCase()} price in india`);
      tagsSet.add(`${cleanSubj.toLowerCase()} features`);
      tagsSet.add(`${cleanSubj.toLowerCase()} pros and cons`);
      tagsSet.add(`is ${cleanSubj.toLowerCase()} worth it`);
      tagsSet.add(`${cleanSubj.toLowerCase()} 2026`);
    } else if (category === "cooking") {
      tagsSet.add(`${lower} recipe`);
      tagsSet.add(`how to make ${cleanSubj.toLowerCase()}`);
      tagsSet.add(`restaurant style ${cleanSubj.toLowerCase()}`);
      tagsSet.add(`${cleanSubj.toLowerCase()} at home`);
      tagsSet.add(`easy ${cleanSubj.toLowerCase()} recipe`);
      tagsSet.add(`halwai style ${cleanSubj.toLowerCase()}`);
      tagsSet.add(`${cleanSubj.toLowerCase()} banane ka tarika`);
      tagsSet.add(`step by step ${cleanSubj.toLowerCase()}`);
      tagsSet.add("indian recipe");
    } else if (category === "vlog") {
      tagsSet.add(`${lower} vlog`);
      tagsSet.add(`daily vlog ${cleanSubj.toLowerCase()}`);
      tagsSet.add(`travel vlog ${cleanSubj.toLowerCase()}`);
      tagsSet.add(`${cleanSubj.toLowerCase()} trip`);
      tagsSet.add(`exploring ${cleanSubj.toLowerCase()}`);
      tagsSet.add(`${cleanSubj.toLowerCase()} tour`);
      tagsSet.add("day in my life");
      tagsSet.add("family vlog");
    } else if (category === "fitness") {
      tagsSet.add(`${lower} workout`);
      tagsSet.add(`${cleanSubj.toLowerCase()} exercises`);
      tagsSet.add(`how to do ${cleanSubj.toLowerCase()}`);
      tagsSet.add(`${cleanSubj.toLowerCase()} at home`);
      tagsSet.add(`${cleanSubj.toLowerCase()} for beginners`);
      tagsSet.add(`${cleanSubj.toLowerCase()} routine`);
      tagsSet.add("fat loss workout");
      tagsSet.add("muscle building tips");
    } else {
      tagsSet.add(`${lower} tutorial`);
      tagsSet.add(`${cleanSubj.toLowerCase()} guide`);
      tagsSet.add(`how to ${cleanSubj.toLowerCase()}`);
      tagsSet.add(`best ${cleanSubj.toLowerCase()} tips`);
      tagsSet.add(`${cleanSubj.toLowerCase()} 2026`);
      tagsSet.add(`${cleanSubj.toLowerCase()} for beginners`);
      tagsSet.add(`${cleanSubj.toLowerCase()} step by step`);
      tagsSet.add(`${cleanSubj.toLowerCase()} explained`);
      tagsSet.add(`${cleanSubj.toLowerCase()} strategy`);
    }

    const tags = Array.from(tagsSet).slice(0, 16);

    // Keywords (Main, Long-tail, Related, Recommended)
    const mainKeywords = [
      lower,
      cleanSubj.toLowerCase(),
      `${primaryTerm} 2026`,
      category === "music" ? `${cleanSubj.toLowerCase()} song` : (category === "cooking" ? `${cleanSubj.toLowerCase()} recipe` : `${cleanSubj.toLowerCase()} guide`),
      category === "music" ? `best of ${cleanSubj.toLowerCase()}` : `best ${primaryTerm}`
    ].filter((v, i, a) => a.indexOf(v) === i);

    let longTailKeywords = [];
    if (category === "music") {
      longTailKeywords = [
        `best ${cleanSubj.toLowerCase()} songs with lyrics`,
        `${cleanSubj.toLowerCase()} lofi chillout mix 1 hour`,
        `${cleanSubj.toLowerCase()} romantic slowed and reverb`,
        `heart touching ${cleanSubj.toLowerCase()} hits non stop`,
        `late night drive ${cleanSubj.toLowerCase()} songs`
      ];
    } else if (category === "gaming") {
      longTailKeywords = [
        `how to play ${cleanSubj.toLowerCase()} like a pro`,
        `${cleanSubj.toLowerCase()} survival walkthrough episode 1`,
        `best pro settings for ${cleanSubj.toLowerCase()}`,
        `${cleanSubj.toLowerCase()} clutch gameplay highlights`,
        `${cleanSubj.toLowerCase()} beginner tips and tricks 2026`
      ];
    } else if (category === "cooking") {
      longTailKeywords = [
        `how to make ${cleanSubj.toLowerCase()} restaurant style at home`,
        `easy and quick ${cleanSubj.toLowerCase()} recipe in 15 minutes`,
        `authentic halwai style ${cleanSubj.toLowerCase()} secret tips`,
        `step by step ${cleanSubj.toLowerCase()} recipe with simple spices`,
        `${cleanSubj.toLowerCase()} banane ki sabse aasan vidhi`
      ];
    } else if (category === "tech") {
      longTailKeywords = [
        `${cleanSubj.toLowerCase()} full in-depth review after 30 days`,
        `${cleanSubj.toLowerCase()} camera and battery real world test`,
        `is ${cleanSubj.toLowerCase()} worth buying in 2026`,
        `${cleanSubj.toLowerCase()} top hidden features and tips`,
        `${cleanSubj.toLowerCase()} pros and cons before you buy`
      ];
    } else {
      longTailKeywords = [
        `how to master ${cleanSubj.toLowerCase()} for beginners`,
        `complete guide to ${cleanSubj.toLowerCase()} step by step`,
        `best practical tips for ${cleanSubj.toLowerCase()} in 2026`,
        `${cleanSubj.toLowerCase()} common mistakes to avoid`,
        `simple ways to improve ${cleanSubj.toLowerCase()}`
      ];
    }

    const relatedKeywords = [
      `${primaryTerm} techniques`,
      `${primaryTerm} best practices`,
      `${primaryTerm} framework`,
      `content creation ${primaryTerm}`,
      `youtube channel ${primaryTerm}`
    ];

    const recommendedKeywords = [
      {
        term: lower,
        why: "Exact match to primary user search intent."
      },
      {
        term: category === "music" ? `${cleanSubj.toLowerCase()} lofi mix` : (category === "cooking" ? `${cleanSubj.toLowerCase()} recipe` : `${cleanSubj.toLowerCase()} for beginners`),
        why: `Captures high search volume within the ${category} category.`
      },
      {
        term: category === "music" ? `best of ${cleanSubj.toLowerCase()}` : (category === "tech" ? `${cleanSubj.toLowerCase()} review` : `how to ${cleanSubj.toLowerCase()}`),
        why: "Directly matches high-intent decision-making searches."
      },
      {
        term: `${cleanSubj.toLowerCase()} 2026`,
        why: "Freshness qualifier signaling up-to-date content."
      },
      {
        term: category === "cooking" ? `restaurant style ${cleanSubj.toLowerCase()}` : (category === "gaming" ? `${cleanSubj.toLowerCase()} pro gameplay` : `${primaryTerm} step by step`),
        why: "Provides targeted value differentiation for viewers."
      }
    ];

    // Relevant YouTube Hashtags
    const cleanWord = (w) => w.replace(/[^a-zA-Z0-9]/g, '');
    const topicTag = cleanWord(primaryTerm) || "YouTube";
    const fullTopicTag = cleanWord(coreTokens.join('')) || "VideoTips";

    let rawHashtags = [
      `#${topicTag}`,
      `#${fullTopicTag}`,
      `#${topicTag}2026`,
      `#${topicTag}India`,
      `#YouTubeIndia`,
      `#ContentCreator`
    ];

    if (category === "music") {
      rawHashtags.push(
        `#${topicTag}Song`, `#Lofi`, `#LofiMusic`, `#RomanticSongs`, `#SlowedAndReverb`,
        `#BollywoodSongs`, `#ChillVibes`, `#SadSongs`, `#Acoustic`, `#HindiSongs`,
        `#MusicVideo`, `#LofiBeats`, `#TrendingSongs`, `#FeelTheMusic`, `#SongOfTheDay`,
        `#IndianMusic`, `#LyricsVideo`, `#MoodBooster`, `#LateNightVibes`, `#Mashup`
      );
    } else if (category === "gaming") {
      rawHashtags.push(
        `#Gaming`, `#Gameplay`, `#Gamer`, `#GamingCommunity`, `#GamerLife`,
        `#Walkthrough`, `#ProGamer`, `#Clutch`, `#GamingVideos`, `#Esports`,
        `#GamingClips`, `#HardcoreGaming`, `#PCGaming`, `#MobileGaming`, `#GameReview`
      );
    } else if (category === "cooking") {
      rawHashtags.push(
        `#Recipe`, `#Cooking`, `#Foodie`, `#IndianFood`, `#HomeCooking`,
        `#StreetFood`, `#Delicious`, `#FoodLover`, `#KitchenSecrets`, `#EasyRecipe`,
        `#QuickRecipe`, `#DesiFood`, `#RestaurantStyle`, `#TastyFood`, `#FoodVlog`
      );
    } else if (category === "tech") {
      rawHashtags.push(
        `#TechReview`, `#Gadgets`, `#Technology`, `#Smartphone`, `#Unboxing`,
        `#TechTips`, `#TechNews`, `#NewTech`, `#TechVideo`, `#ReviewVideo`,
        `#TechIndia`, `#MobileReview`, `#GadgetReview`, `#HonestReview`
      );
    } else if (category === "fitness") {
      rawHashtags.push(
        `#Fitness`, `#Workout`, `#GymMotivation`, `#FitnessGoals`, `#FatLoss`,
        `#MuscleBuilding`, `#HomeWorkout`, `#HealthyLiving`, `#BodyTransformation`,
        `#FitnessJourney`, `#WorkoutRoutine`, `#FitIndia`, `#GymLife`
      );
    } else {
      rawHashtags.push(
        `#${topicTag}Tips`, `#${topicTag}Tutorial`, `#${topicTag}Guide`,
        `#Learn${topicTag}`, `#${topicTag}Strategy`, `#${topicTag}Explained`,
        `#HowTo`, `#Tutorial`, `#StepByStep`, `#Education`, `#SkillDevelopment`
      );
    }

    rawHashtags.push(
      "#YouTubeCreator", "#VideoCreator", "#YouTubeTips", "#ChannelGrowth",
      "#VideoProduction", "#YouTubeStrategy", "#CreatorEconomy"
    );

    const hashtags = Array.from(new Set(rawHashtags.filter(h => h.length > 2))).slice(0, 34);

    // Category-Specific Optimization Tips
    let tips = [];
    if (category === "music") {
      tips = [
        {
          title: "Mood-Matched Thumbnail Art",
          desc: `Use deep ambient or warm color palettes that visually communicate the mood of "${cleanSubj}".`
        },
        {
          title: "Include Song Timestamps & Chapters",
          desc: "Add precise track timestamps in the description so listeners can jump to their favorite parts."
        },
        {
          title: "320kbps Audio Quality First",
          desc: "YouTube algorithms detect high watch-time on audio uploads when audio mixing and bitrate are pristine."
        },
        {
          title: "Seed into Topic Playlists",
          desc: "Group this track into a thematic playlist (e.g. 'Late Night Drive' or 'Chillout 2026') to earn continuous autoplay views."
        },
        {
          title: "Keep Hashtags to Mood & Genre",
          desc: "Use 3 to 5 targeted tags like #Lofi #RomanticSongs #HindiSongs rather than unrelated viral tags."
        },
        {
          title: "Add On-Screen Lyric Animations",
          desc: "Lyric-focused videos enjoy significantly higher viewer retention and repeat plays."
        }
      ];
    } else if (category === "gaming") {
      tips = [
        {
          title: "Thumbnail Clutch Moment",
          desc: `Highlight a high-stakes action frame or dramatic game reaction rather than a plain logo or menu screenshot.`
        },
        {
          title: "Hook Within the First 10 Seconds",
          desc: "Tease the most intense play or funny fail right at 0:00 before jumping into the main match."
        },
        {
          title: "Front-load Game Name & Mode",
          desc: `Keep "${cleanSubj}" clearly visible in the first 35 characters of your title for mobile gamer feeds.`
        },
        {
          title: "Use End Screens for Episode Binging",
          desc: "Link to your playlist or next episode during the final 20 seconds to maximize session watch-time."
        },
        {
          title: "Keep Video Pacing Fast",
          desc: "Cut out boring inventory management or loading screens to preserve high audience retention."
        },
        {
          title: "Pin Top Comment with Community Question",
          desc: "Ask viewers for their favorite loadout or strategy to drive early comment engagement."
        }
      ];
    } else if (category === "cooking") {
      tips = [
        {
          title: "5-Second Beauty Shot Hook",
          desc: `Show the mouth-watering final presentation of "${cleanSubj}" in the opening 5 seconds before prep begins.`
        },
        {
          title: "Put Ingredients in Top 3 Lines",
          desc: "List core ingredients and quantities clearly in the description so viewers don't need to scrub through the video."
        },
        {
          title: "Prep vs Cooking Timestamps",
          desc: "Include chapters for ingredients, masala preparation, and final plating for Google Key Moments."
        },
        {
          title: "Natural Light Close-Up Shots",
          desc: "Bright, close-up sizzle shots on thumbnails dramatically increase click-through rates on recipe searches."
        },
        {
          title: "Mention Cooking Time in Title/Desc",
          desc: "Time qualifiers (e.g., '15 Minutes', 'Easy') reduce viewer friction and increase clicks."
        },
        {
          title: "Answer Common Cooking Mistakes",
          desc: "Mention how to prevent curdling, burning, or excess salt to establish authority in your niche."
        }
      ];
    } else if (category === "tech") {
      tips = [
        {
          title: "Unbiased Pros & Cons Summary",
          desc: `Provide an honest summary of strengths and weaknesses of "${cleanSubj}" in the description.`
        },
        {
          title: "Time-stamped Spec Chapters",
          desc: "Add chapters for unboxing, build quality, camera samples, battery life, and final buying verdict."
        },
        {
          title: "Side-by-Side Comparison Shot",
          desc: "Use a clean, high-contrast side-by-side thumbnail showing the device in real hand use."
        },
        {
          title: "Address Price-to-Value Immediately",
          desc: "Viewers search tech reviews to make buying decisions; state the price and verdict clearly."
        },
        {
          title: "Include Direct Search Modifiers",
          desc: "Keywords like 'worth it in 2026' and 'before you buy' match high-intent prospective customers."
        },
        {
          title: "Disclose Testing Duration",
          desc: "Mentioning 'After 30 Days' or 'Long-term' establishes trust over rushed launch-day unboxings."
        }
      ];
    } else {
      tips = [
        {
          title: "Front-load Core Keywords",
          desc: `Place "${primaryTerm}" within the first 30–45 characters so mobile viewers see it immediately.`
        },
        {
          title: "Match Viewer Search Intent",
          desc: "Ensure your video directly answers the promise of your title to sustain high watch time."
        },
        {
          title: "Avoid Keyword Stuffing",
          desc: "Write for human viewers first. Use tags and description text for synonyms and secondary keywords."
        },
        {
          title: "Sync First 2 Lines of Description",
          desc: "Include your main topic keyword naturally in the first two sentences of your video description."
        },
        {
          title: "Keep Hashtags Focused",
          desc: "Add 3 to 5 targeted hashtags at the end of your description; excessive tags can be flagged as spam."
        },
        {
          title: "Complement Your Thumbnail",
          desc: "Use your thumbnail for a bold visual hook rather than repeating your full title text verbatim."
        }
      ];
    }

    return {
      submittedInput: input,
      analysis: {
        score: score,
        statusText: statusText,
        relevance: "High (Targeted)",
        intent: intent,
        clarity: charCount > 15 ? "Clear & Focused" : "Moderate",
        readability: "Natural Phrasing",
        clickPotential: score >= 80 ? "Strong / Intent-Driven" : "Moderate",
        lengthQuality: lengthQuality,
        strengths: strengths,
        weaknesses: weaknesses,
        improvements: improvements
      },
      titles: improvedTitles,
      tags: tags,
      keywords: {
        main: mainKeywords,
        longTail: longTailKeywords,
        related: relatedKeywords,
        recommended: recommendedKeywords
      },
      hashtags: hashtags,
      tips: tips
    };
  }

  function escapeHtml(text) {
    if (text === null || text === undefined) return '';
    return String(text)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  // --- Safe Result Rendering ---
  function renderResults(data) {
    state.results = data;

    // Summary
    const displayTopic = $('submittedTopicDisplay');
    if (displayTopic) displayTopic.textContent = data.submittedInput;

    // 1. Title Analysis
    const scoreNum = $('scoreNumber');
    if (scoreNum) scoreNum.textContent = data.analysis.score;

    const scoreStatus = $('scoreStatusText');
    if (scoreStatus) scoreStatus.textContent = data.analysis.statusText;

    const relVal = $('relevanceVal');
    if (relVal) relVal.textContent = data.analysis.relevance;

    const intVal = $('intentVal');
    if (intVal) intVal.textContent = data.analysis.intent;

    const clarVal = $('clarityVal');
    if (clarVal) clarVal.textContent = data.analysis.clarity;

    const readVal = $('readabilityVal');
    if (readVal) readVal.textContent = data.analysis.readability;

    const clickVal = $('clickPotentialVal');
    if (clickVal) clickVal.textContent = data.analysis.clickPotential;

    const lenVal = $('lengthQualityVal');
    if (lenVal) lenVal.textContent = data.analysis.lengthQuality;

    // Strengths
    const strengthsList = $('strengthsList');
    if (strengthsList) {
      strengthsList.innerHTML = data.analysis.strengths.length > 0 
        ? data.analysis.strengths.map(s => `<li>${escapeHtml(s)}</li>`).join('')
        : '<li>Subject is clearly stated.</li>';
    }

    // Weaknesses / Improvements
    const weaknessesList = $('weaknessesList');
    if (weaknessesList) {
      const weaknessItems = [...data.analysis.weaknesses, ...data.analysis.improvements];
      weaknessesList.innerHTML = weaknessItems.length > 0
        ? weaknessItems.map(w => `<li>${escapeHtml(w)}</li>`).join('')
        : '<li>No major weaknesses identified.</li>';
    }

    // 2. Improved Titles
    const titlesList = $('titlesList');
    if (titlesList) {
      titlesList.innerHTML = data.titles.map(t => `
        <div class="title-item-card ${t.recommended ? 'recommended' : ''}">
          ${t.recommended ? '<div class="title-badge-rec">⭐ Best Recommended</div>' : ''}
          <div class="title-text">${escapeHtml(t.title)}</div>
          <div class="title-reason">${escapeHtml(t.reason)}</div>
        </div>
      `).join('');
    }

    // 3. Tags
    const tagsChips = $('tagsChips');
    if (tagsChips) {
      tagsChips.innerHTML = data.tags.map(tag => `
        <span class="tag-chip">${escapeHtml(tag)}</span>
      `).join('');
    }

    // 4. Keywords
    const mainKw = $('mainKeywordsChips');
    if (mainKw) {
      mainKw.innerHTML = data.keywords.main.map(k => `
        <span class="tag-chip">${escapeHtml(k)}</span>
      `).join('');
    }

    const longTailKw = $('longTailKeywordsChips');
    if (longTailKw) {
      longTailKw.innerHTML = data.keywords.longTail.map(k => `
        <span class="tag-chip">${escapeHtml(k)}</span>
      `).join('');
    }

    const relatedKw = $('relatedKeywordsChips');
    if (relatedKw) {
      relatedKw.innerHTML = data.keywords.related.map(k => `
        <span class="tag-chip">${escapeHtml(k)}</span>
      `).join('');
    }

    const recKw = $('recommendedKeywordsList');
    if (recKw) {
      recKw.innerHTML = data.keywords.recommended.map(item => `
        <div class="rec-keyword-card">
          <span class="rec-kw-name">${escapeHtml(item.term)}</span>
          <span class="rec-kw-why">
            <i class="info-icon" title="Why this keyword?">i</i>
            ${escapeHtml(item.why)}
          </span>
        </div>
      `).join('');
    }

    // 5. Hashtags
    const hashtagsContainer = $('hashtagsContainer');
    if (hashtagsContainer) {
      hashtagsContainer.innerHTML = data.hashtags.map(h => `
        <span class="hashtag-chip">${escapeHtml(h)}</span>
      `).join('');
    }

    // 6. Tips
    const tipsGrid = $('tipsGrid');
    if (tipsGrid) {
      tipsGrid.innerHTML = data.tips.map(tip => `
        <div class="tip-card">
          <div class="tip-title">
            <span>💡</span>
            <span>${escapeHtml(tip.title)}</span>
          </div>
          <p class="tip-desc">${escapeHtml(tip.desc)}</p>
        </div>
      `).join('');
    }

    // Make results visible
    const resultsWrapper = $('resultsWrapper');
    if (resultsWrapper) {
      resultsWrapper.style.display = 'block';
      setTimeout(() => {
        resultsWrapper.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 50);
    }
  }

  // --- Copy Handlers ---
  function copyToClipboard(text, btnElement, originalText) {
    if (!text || !btnElement) return;

    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(() => {
        showCopySuccess(btnElement, originalText);
      }).catch(() => {
        fallbackCopy(text, btnElement, originalText);
      });
    } else {
      fallbackCopy(text, btnElement, originalText);
    }
  }

  function fallbackCopy(text, btnElement, originalText) {
    const textArea = document.createElement('textarea');
    textArea.value = text;
    textArea.style.position = 'fixed';
    textArea.style.left = '-999999px';
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    try {
      document.execCommand('copy');
      showCopySuccess(btnElement, originalText);
    } catch (err) {
      console.error('Fallback copy failed', err);
    }
    document.body.removeChild(textArea);
  }

  function showCopySuccess(btnElement, originalText) {
    btnElement.classList.add('copied');
    btnElement.innerHTML = `
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
      Copied!
    `;
    setTimeout(() => {
      btnElement.classList.remove('copied');
      btnElement.innerHTML = `
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>
        ${originalText}
      `;
    }, 2000);
  }

  function setupCopyHandlers() {
    const copyTitlesBtn = $('copyTitlesBtn');
    if (copyTitlesBtn) {
      copyTitlesBtn.addEventListener('click', () => {
        if (!state.results) return;
        const text = state.results.titles.map(t => t.title).join('\n');
        copyToClipboard(text, copyTitlesBtn, 'Copy Titles');
      });
    }

    const copyTagsBtn = $('copyTagsBtn');
    if (copyTagsBtn) {
      copyTagsBtn.addEventListener('click', () => {
        if (!state.results) return;
        const text = state.results.tags.join(', ');
        copyToClipboard(text, copyTagsBtn, 'Copy Tags');
      });
    }

    const copyKeywordsBtn = $('copyKeywordsBtn');
    if (copyKeywordsBtn) {
      copyKeywordsBtn.addEventListener('click', () => {
        if (!state.results) return;
        const allKws = [
          ...state.results.keywords.main,
          ...state.results.keywords.longTail,
          ...state.results.keywords.related
        ];
        const text = Array.from(new Set(allKws)).join('\n');
        copyToClipboard(text, copyKeywordsBtn, 'Copy Keywords');
      });
    }

    const copyHashtagsBtn = $('copyHashtagsBtn');
    if (copyHashtagsBtn) {
      copyHashtagsBtn.addEventListener('click', () => {
        if (!state.results) return;
        const text = state.results.hashtags.join(' ');
        copyToClipboard(text, copyHashtagsBtn, 'Copy Hashtags');
      });
    }
  }

  // --- Generation Workflow ---
  function handleGenerateSEO() {
    const mainInput = $('mainInput');
    if (!mainInput) return;

    const rawVal = mainInput.value.trim();

    // Validation
    if (!rawVal) {
      showAlert("Please enter a YouTube title or video topic first.", false);
      mainInput.focus();
      return;
    }

    hideAlert();
    state.isLoading = true;

    const resultsWrapper = $('resultsWrapper');
    const loadingBox = $('loadingBox');
    const loadingText = $('loadingStatusText');

    if (resultsWrapper) resultsWrapper.style.display = 'none';
    if (loadingBox) loadingBox.style.display = 'block';

    const loadingStages = [
      "Analyzing your topic…",
      "Generating SEO suggestions…",
      "Preparing your results…"
    ];

    let stageIdx = 0;
    if (loadingText) loadingText.textContent = loadingStages[0];

    const stageInterval = setInterval(() => {
      stageIdx++;
      if (stageIdx < loadingStages.length && loadingText) {
        loadingText.textContent = loadingStages[stageIdx];
      }
    }, 380);

    setTimeout(() => {
      clearInterval(stageInterval);
      state.isLoading = false;
      if (loadingBox) loadingBox.style.display = 'none';

      try {
        const generatedData = analyzeTopic(rawVal);
        renderResults(generatedData);
      } catch (err) {
        console.error("Analysis generation error:", err);
        showAlert("Something went wrong. Please try again.", true);
      }
    }, 1100);
  }

  function showAlert(msg, isRetryable) {
    const alertBox = $('alertBox');
    const alertMsg = $('alertMsg');
    const alertBtn = $('alertBtn');

    if (alertMsg) alertMsg.textContent = msg;
    if (alertBox) alertBox.style.display = 'flex';

    if (alertBtn) {
      if (isRetryable) {
        alertBtn.style.display = 'inline-block';
        alertBtn.textContent = 'Try Again';
        alertBtn.onclick = handleGenerateSEO;
      } else {
        alertBtn.style.display = 'none';
      }
    }
  }

  function hideAlert() {
    const alertBox = $('alertBox');
    if (alertBox) alertBox.style.display = 'none';
  }

  // --- Input & Example Events ---
  function setupInputEvents() {
    const mainInput = $('mainInput');
    const clearBtn = $('clearInputBtn');
    const generateBtn = $('generateBtn');

    if (mainInput && clearBtn) {
      mainInput.addEventListener('input', () => {
        clearBtn.style.display = mainInput.value.length > 0 ? 'block' : 'none';
        hideAlert();
      });

      clearBtn.addEventListener('click', () => {
        mainInput.value = '';
        clearBtn.style.display = 'none';
        mainInput.focus();
      });

      mainInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          handleGenerateSEO();
        }
      });
    }

    if (generateBtn) {
      generateBtn.addEventListener('click', handleGenerateSEO);
    }

    // Example topic chips
    document.querySelectorAll('.example-chip').forEach(chip => {
      chip.addEventListener('click', () => {
        const topic = chip.getAttribute('data-topic') || chip.textContent.trim();
        if (mainInput) {
          mainInput.value = topic;
          if (clearBtn) clearBtn.style.display = 'block';
          hideAlert();
          handleGenerateSEO();
        }
      });
    });
  }

  // --- FAQ Accordion ---
  function setupFAQ() {
    document.querySelectorAll('.faq-question').forEach(btn => {
      btn.addEventListener('click', () => {
        const item = btn.parentElement;
        if (item) item.classList.toggle('open');
      });
    });
  }

  // --- Contact Form ---
  function setupContactForm() {
    const form = $('contactForm');
    const successMsg = $('contactSuccess');
    if (!form) return;

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const submitBtn = form.querySelector('button[type="submit"]');
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.textContent = "Sending...";
      }

      setTimeout(() => {
        form.reset();
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.textContent = "Send Message";
        }
        if (successMsg) {
          successMsg.style.display = 'block';
          setTimeout(() => {
            successMsg.style.display = 'none';
          }, 4000);
        }
      }, 600);
    });
  }

  // --- Initializer ---
  document.addEventListener('DOMContentLoaded', () => {
    initRouter();
    setupInputEvents();
    setupCopyHandlers();
    setupFAQ();
    setupContactForm();
  });
})();