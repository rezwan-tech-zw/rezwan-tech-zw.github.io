# India’s YouTube SEO (YT SEO Pro)

A professional, production-ready YouTube SEO toolkit designed for content creators. Analyze video titles and topics to generate topic-relevant titles, SEO tags, structured keywords, hashtags, and optimization tips.

## Key Features

1. **Title SEO Analysis**: Evaluates title structure, readability, clarity, search intent, and provides an AI-estimated score (0–100) with clear non-guarantee disclosures.
2. **AI Improved Titles**: Up to 5 topic-aware title variants with rationales and highlighted recommendation.
3. **SEO Tags**: Clean tag chips with individual "Copy Tags" button.
4. **Structured Keywords**: Main, Long-tail, Related, and 5 Recommended keywords with "Why this keyword?" explanations.
5. **Hashtags**: Generates relevant hashtags (up to 40 max) without keyword stuffing or generic spam.
6. **SEO Optimization Tips**: Actionable best practices tailored to the topic.
7. **Copy Controls**: Dedicated copy buttons for each section with temporary "Copied!" feedback.
8. **Educational Content**: Original, comprehensive guides covering titles, search intent, descriptions, and common mistakes.
9. **AdSense Ready**: Clean reserved ad slots adhering to policy.
10. **Zero External Dependencies**: Fast, lightweight vanilla HTML5, CSS3, and modern JavaScript.

## Getting Started

### Static / Direct Browser Opening
Simply double-click or open `index.html` in any web browser.

### Node.js Production Hosting
```bash
npm install
npm start
```
Open `http://localhost:3000`.